document.querySelector("#monster1").addEventListener("click", function(){
    document.querySelector("#monster1").style.visibility = "hidden";
})

document.querySelector("#monster2").addEventListener("click", function(){
    document.querySelector("#monster2").style.visibility = "hidden";
})

document.querySelector("#monster3").addEventListener("click", function(){
    document.querySelector("#monster3").style.visibility = "hidden";
    
})

document.querySelector("#monster4").addEventListener("click", function(){
    document.querySelector("#monster4").style.visibility = "hidden";
    
})

